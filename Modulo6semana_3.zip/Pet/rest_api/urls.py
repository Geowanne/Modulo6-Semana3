from django.urls import path

from rest_framework.routers import SimpleRouter

from rest_api.views import AgendamentoModelViewSet, hello_world
from rest_api.views import ContatoModelViewSet, contato_api

app_name = 'rest_api'

router = SimpleRouter(trailing_slash=False)
router.register('agendamento', AgendamentoModelViewSet)
router.register('contatos', ContatoModelViewSet) #teste


urlpatterns = [
    path('hello_world', hello_world, name='hello_world_api',),
    path('contato_api', contato_api, name='contata_ap_api',)
]

urlpatterns += router.urls